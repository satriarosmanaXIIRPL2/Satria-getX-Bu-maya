package com.example.get_x_satria

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
