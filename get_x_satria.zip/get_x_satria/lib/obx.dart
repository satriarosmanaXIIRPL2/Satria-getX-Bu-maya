import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'GetBuilder.dart';

class obx extends StatelessWidget {
  const obx({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('State Management'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: (){
                  Navigator.push(context,MaterialPageRoute(builder: (context) => const getBuilder() ));
                },
                child: Container(
                  width: 300,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.amber,
                    borderRadius: BorderRadius.all(Radius.circular(10))
                  ),
                  child: Center(child: Text(textAlign: TextAlign.center,'Get Builder',style: TextStyle(color: Colors.white),)),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 20,
            width: 40,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 300,
                height: 50,
                decoration: BoxDecoration(
                    color: Colors.amber,
                    borderRadius: BorderRadius.all(Radius.circular(10))
                ),
                child: Center(child: Text(textAlign: TextAlign.center,'obx',style: TextStyle(color: Colors.white),)),
              ),
            ],
          ),
          SizedBox(
            height: 20,
            width: 40,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 300,
                height: 50,
                decoration: BoxDecoration(
                    color: Colors.amber,
                    borderRadius: BorderRadius.all(Radius.circular(10))
                ),
                child: Center(child: Text(textAlign: TextAlign.center,'sum xy',style: TextStyle(color: Colors.white),)),
              ),
            ],
          )
        ],
      )
      ,
    );
  }
}
